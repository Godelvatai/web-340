/**
 * Author:      Dustin Craven
 * Date:        5/19/24
 * File Name:   failing-script.js
 * Description: File for game-characters.js to use with Node.js child processes.
 */
"use strict";

throw new Error("This script is supposed to fail");